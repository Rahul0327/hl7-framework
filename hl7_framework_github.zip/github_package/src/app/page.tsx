import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="bg-blue-700 text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">HL7 Framework Master Data Model</h1>
          <p className="mt-2 text-blue-100">A comprehensive approach to healthcare interoperability</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <section className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8 mb-8">
          <h2 className="text-2xl font-bold text-blue-800 mb-4">Welcome to the HL7 Framework Documentation</h2>
          <p className="text-gray-700 mb-4">
            This website provides comprehensive documentation for the HL7 Framework Master Data Model, 
            a unified approach to healthcare data representation and exchange that integrates concepts 
            from multiple HL7 standards including HL7 v2.x, HL7 v3 Reference Information Model (RIM), 
            Clinical Document Architecture (CDA), and Fast Healthcare Interoperability Resources (FHIR).
          </p>
          <div className="mt-6">
            <Link 
              href="/docs/overview" 
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md transition-colors"
            >
              Explore Documentation
            </Link>
          </div>
        </section>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-blue-800 mb-3">Core Data Model</h3>
            <p className="text-gray-700 mb-4">
              Explore the comprehensive master data model that defines entities, relationships, 
              data types, and terminology bindings aligned with HL7 standards.
            </p>
            <Link 
              href="/docs/data-model" 
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              View Data Model →
            </Link>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-blue-800 mb-3">HL7 Mappings</h3>
            <p className="text-gray-700 mb-4">
              Detailed mappings between the data model and various HL7 standards to facilitate 
              implementation and integration across healthcare systems.
            </p>
            <Link 
              href="/docs/mappings" 
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              View Mappings →
            </Link>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-blue-800 mb-3">Implementation Guide</h3>
            <p className="text-gray-700 mb-4">
              Practical guidance for implementing the HL7 Framework Master Data Model in 
              healthcare information systems.
            </p>
            <Link 
              href="/docs/implementation" 
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              View Implementation Guide →
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-gray-100 py-6 mt-12">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2025 HL7 Framework Master Data Model</p>
        </div>
      </footer>
    </div>
  )
}
