'use client';

import { useEffect } from 'react';
import MobileNavigation from '@/components/MobileNavigation';
import SearchComponent from '@/components/SearchComponent';

export default function DocsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Add scroll to anchor functionality
  useEffect(() => {
    // Handle initial hash on page load
    if (window.location.hash) {
      const id = window.location.hash.substring(1);
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }

    // Add click event listeners to all anchor links
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      
      if (anchor && anchor.hash && anchor.href.includes(window.location.pathname)) {
        e.preventDefault();
        const id = anchor.hash.substring(1);
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
          window.history.pushState(null, '', anchor.hash);
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    
    return () => {
      document.removeEventListener('click', handleAnchorClick);
    };
  }, []);

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-gray-50 p-6 border-r border-gray-200 md:h-screen md:sticky md:top-16 overflow-y-auto">
        <div className="mb-6">
          <SearchComponent />
        </div>
        <nav className="space-y-1">
          <h3 className="font-semibold text-gray-900 mb-3">Documentation</h3>
          <ul className="space-y-2">
            <li><a href="/docs/overview" className="block text-blue-600 hover:text-blue-800 transition-colors">Overview</a></li>
            <li>
              <a href="/docs/data-model" className="block text-blue-600 hover:text-blue-800 transition-colors">Data Model</a>
              <ul className="pl-4 mt-1 space-y-1">
                <li><a href="/docs/data-model#core-entities" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Core Entities</a></li>
                <li><a href="/docs/data-model#clinical-entities" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Clinical Entities</a></li>
                <li><a href="/docs/data-model#administrative-entities" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Administrative Entities</a></li>
                <li><a href="/docs/data-model#data-types" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Data Types</a></li>
              </ul>
            </li>
            <li>
              <a href="/docs/mappings" className="block text-blue-600 hover:text-blue-800 transition-colors">HL7 Mappings</a>
              <ul className="pl-4 mt-1 space-y-1">
                <li><a href="/docs/mappings#hl7-v2" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">HL7 v2.x</a></li>
                <li><a href="/docs/mappings#hl7-v3" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">HL7 v3 RIM</a></li>
                <li><a href="/docs/mappings#cda" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">CDA</a></li>
                <li><a href="/docs/mappings#fhir" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">FHIR</a></li>
              </ul>
            </li>
            <li>
              <a href="/docs/implementation" className="block text-blue-600 hover:text-blue-800 transition-colors">Implementation</a>
              <ul className="pl-4 mt-1 space-y-1">
                <li><a href="/docs/implementation#security" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Security & Privacy</a></li>
                <li><a href="/docs/implementation#interoperability" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Interoperability</a></li>
                <li><a href="/docs/implementation#scenarios" className="block text-gray-600 hover:text-blue-800 text-sm transition-colors">Implementation Scenarios</a></li>
              </ul>
            </li>
            <li><a href="/docs/validation" className="block text-blue-600 hover:text-blue-800 transition-colors">Validation</a></li>
          </ul>
        </nav>
      </aside>
      <main className="flex-1 p-6 md:p-8 max-w-4xl mx-auto w-full">
        <MobileNavigation />
        {children}
      </main>
    </div>
  )
}
