import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "HL7 Framework Master Data Model",
  description: "A comprehensive approach to healthcare interoperability",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <header className="bg-blue-700 text-white py-4 sticky top-0 z-10 shadow-md">
            <div className="container mx-auto px-4 flex justify-between items-center">
              <a href="/" className="text-xl font-bold">HL7 Framework</a>
              <nav>
                <ul className="flex space-x-6">
                  <li><a href="/docs/overview" className="hover:text-blue-200 transition-colors">Overview</a></li>
                  <li><a href="/docs/data-model" className="hover:text-blue-200 transition-colors">Data Model</a></li>
                  <li><a href="/docs/mappings" className="hover:text-blue-200 transition-colors">Mappings</a></li>
                  <li><a href="/docs/implementation" className="hover:text-blue-200 transition-colors">Implementation</a></li>
                </ul>
              </nav>
            </div>
          </header>

          <div className="flex-grow">
            {children}
          </div>

          <footer className="bg-gray-100 py-6 mt-12 border-t border-gray-200">
            <div className="container mx-auto px-4 text-center text-gray-600">
              <p>© 2025 HL7 Framework Master Data Model</p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
